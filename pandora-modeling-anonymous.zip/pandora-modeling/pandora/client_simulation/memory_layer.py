from __future__ import annotations

from pandora.schemas import MemoryItem

def _parse_session_id(session_id: str | int | None) -> int | None:
    if session_id is None:
        return None
    try:
        return int(str(session_id).strip())
    except ValueError:
        return None

def filter_memories_by_session_visibility(
    memories: list[MemoryItem],
    session_id: str | int | None,
    turn_id: str | int | None = None,
) -> list[MemoryItem]:
    current_session = _parse_session_id(session_id)
    current_turn = _parse_session_id(turn_id)
    if current_session is None:
        return [
            memory
            for memory in memories
            if getattr(memory, "visibility_start_session", None) is None
        ]
    visible: list[MemoryItem] = []
    for memory in memories:
        visibility_start = getattr(memory, "visibility_start_session", None)
        if visibility_start is None:
            visible.append(memory)
            continue
        visibility_session = int(visibility_start)
        if visibility_session < current_session:
            visible.append(memory)
            continue
        if visibility_session == current_session:
            visibility_turn = getattr(memory, "visibility_start_turn", None)
            if visibility_turn is None or (current_turn is not None and int(visibility_turn) <= current_turn):
                visible.append(memory)
    return visible
