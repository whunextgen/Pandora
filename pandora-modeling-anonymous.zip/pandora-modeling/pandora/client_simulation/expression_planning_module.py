from __future__ import annotations


from collections.abc import Callable


from dataclasses import dataclass


from typing import Any, TypeVar


from pandora.client_simulation.linguistic_layer import (
    build_session_aware_linguistic_plan,
    get_recent_client_utterances,
)


from pandora.schemas import (
    AttributionFrame,
    DialogueTurnRecord,
    DisclosurePlan,
    LatentPsychologicalState,
    LinguisticRealizationPlan,
    SubjectiveAppraisal,
)


T = TypeVar("T")


StepRunner = Callable[[str, Callable[[], T]], T]


@dataclass(frozen=True)
class ExpressionPlanningRequest:
    """Surface-realization inputs; content and disclosure are already decided."""

    latent_state_after: LatentPsychologicalState
    subjective_appraisal: SubjectiveAppraisal
    attribution_frame: AttributionFrame
    disclosure_plan: DisclosurePlan
    response_act_plan: dict[str, Any]
    recent_dialogue_history: list[DialogueTurnRecord]
    language: str = "zh"
    language_style_stats: dict[str, Any] | None = None


@dataclass(frozen=True)
class ExpressionPlanningResult:
    linguistic_realization_plan: LinguisticRealizationPlan


def process_expression_planning(
    request: ExpressionPlanningRequest,
    *,
    step_runner: StepRunner | None = None,
) -> ExpressionPlanningResult:
    def build() -> LinguisticRealizationPlan:
        return build_session_aware_linguistic_plan(
            latent_state_after=request.latent_state_after,
            subjective_appraisal=request.subjective_appraisal,
            attribution_frame=request.attribution_frame,
            disclosure_plan=request.disclosure_plan,
            response_act_plan=request.response_act_plan,
            language=request.language,
            recent_client_utterances=get_recent_client_utterances(
                request.recent_dialogue_history
            ),
            language_style_stats=request.language_style_stats,
        )

    plan = step_runner("linguistic_plan", build) if step_runner else build()
    return ExpressionPlanningResult(linguistic_realization_plan=plan)
