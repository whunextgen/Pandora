from __future__ import annotations


from collections.abc import Sequence


from typing import Any, Literal


from pandora.client.expression_planning import build_linguistic_realization_plan


from pandora.schemas import (
    AttributionFrame,
    DialogueTurnRecord,
    DisclosurePlan,
    LatentPsychologicalState,
    LinguisticRealizationPlan,
    SubjectiveAppraisal,
)


_HEDGE_MARKERS = {
    "可能",
    "也许",
    "大概",
    "好像",
    "有点",
    "有一点",
    "有一点吧",
    "我觉得",
    "我也不知道",
    "不知道",
    "不太确定",
    "吧",
}


_MARKER_KEYS = (
    "frequent_markers",
    "marker_counts",
    "style_markers",
    "discourse_markers",
    "lexical_markers",
    "frequent_fillers",
    "fillers",
    "hedges",
)


def get_recent_client_utterances(
    dialogue_history: Sequence[DialogueTurnRecord],
    *,
    limit: int = 5,
) -> list[str]:
    utterances: list[str] = []
    for turn in dialogue_history[-limit:]:
        text = turn.client_response.utterance.strip()
        if text:
            utterances.append(text)
    return utterances


def _response_act_constraints(response_act_plan: dict[str, Any] | None) -> list[str]:
    if not response_act_plan:
        return []

    constraints: list[str] = []
    main_act = response_act_plan.get("main_act")
    max_introspection = response_act_plan.get("max_introspection")

    if response_act_plan.get("must_answer_question"):
        constraints.append("Answer the therapist's question directly before adding feelings or context.")
    if response_act_plan.get("answer_first"):
        constraints.append("Put the concrete answer in the first clause or first sentence.")
    if main_act == "logistics_response":
        constraints.append("For scheduling or room logistics, give a short practical reply and do not introspect.")
    elif main_act == "answer_fact":
        constraints.append("Provide the requested factual detail; keep psychological interpretation minimal.")
    elif main_act == "express_feeling_with_example":
        constraints.append("Name the feeling and include one concrete example instead of a broad pattern explanation.")
    elif main_act in {"soft_resistance_or_clarification", "defensive_clarification"}:
        constraints.append("It is acceptable to hesitate, qualify the premise, push back softly, or ask for clarification.")

    if max_introspection == "none":
        constraints.append("Do not mention body sensations, schemas, old situations, or deep patterns.")
    elif max_introspection == "low":
        constraints.append("Use at most one brief emotional sentence; avoid extended self-analysis.")

    factual_slot = response_act_plan.get("factual_slot")
    if factual_slot:
        constraints.append(f"Factual slot to satisfy: {factual_slot}.")

    return constraints


def _language_constraints(language: str) -> list[str]:
    if language.lower() in {"zh", "zh-cn", "chinese"}:
        return [
            "Write the client utterance in natural spoken Chinese.",
            "Avoid translated English counseling templates and abstract clinical wording.",
        ]
    return []


def _dedupe_constraints(recent_client_utterances: Sequence[str]) -> list[str]:
    if not recent_client_utterances:
        return []
    return [
        "Avoid repeating the same fact, memory, or psychological explanation already stated unless the therapist asks for it.",
        "Habitual fillers, hedges, discourse markers, and familiar sentence shapes may recur naturally; do not suppress them merely because they appeared in recent turns.",
        "Do not reproduce a nearly identical complete sentence from a recent turn.",
    ]


def _number(value: Any) -> float | None:
    return float(value) if isinstance(value, (int, float)) else None


def _turn_length_stats(language_style_stats: dict[str, Any] | None) -> dict[str, Any]:
    stats = language_style_stats or {}
    turn_length = stats.get("turn_length")
    if isinstance(turn_length, dict):
        return turn_length
    return {}


def _sentence_stats(language_style_stats: dict[str, Any] | None) -> dict[str, Any]:
    stats = language_style_stats or {}
    for key in ("sentence_count", "sentences_per_turn", "turn_sentences"):
        value = stats.get(key)
        if isinstance(value, dict):
            return value
    return {}


def _marker_counts_from_value(value: Any) -> dict[str, float]:
    result: dict[str, float] = {}
    if isinstance(value, dict):
        for marker, count in value.items():
            marker_text = str(marker).strip()
            if not marker_text or len(marker_text) > 12:
                continue
            if isinstance(count, (int, float)):
                result[marker_text] = max(result.get(marker_text, 0.0), float(count))
            elif isinstance(count, dict):
                nested_count = count.get("count") or count.get("frequency") or count.get("n")
                if isinstance(nested_count, (int, float)):
                    result[marker_text] = max(result.get(marker_text, 0.0), float(nested_count))
    elif isinstance(value, list):
        for item in value:
            if isinstance(item, str):
                marker_text = item.strip()
                if marker_text and len(marker_text) <= 12:
                    result[marker_text] = max(result.get(marker_text, 0.0), 1.0)
            elif isinstance(item, dict):
                marker = item.get("marker") or item.get("text") or item.get("token") or item.get("phrase")
                count = item.get("count") or item.get("frequency") or item.get("n") or 1
                marker_text = str(marker or "").strip()
                if marker_text and len(marker_text) <= 12 and isinstance(count, (int, float)):
                    result[marker_text] = max(result.get(marker_text, 0.0), float(count))
    return result


def _preferred_marker_counts(language_style_stats: dict[str, Any] | None) -> dict[str, float]:
    stats = language_style_stats or {}
    counts: dict[str, float] = {}
    for key in _MARKER_KEYS:
        for marker, count in _marker_counts_from_value(stats.get(key)).items():
            counts[marker] = max(counts.get(marker, 0.0), count)

    # Some distillers group style statistics under a lexical/style subsection.
    for section_key in ("lexical", "style", "language", "discourse"):
        section = stats.get(section_key)
        if not isinstance(section, dict):
            continue
        for key in _MARKER_KEYS:
            for marker, count in _marker_counts_from_value(section.get(key)).items():
                counts[marker] = max(counts.get(marker, 0.0), count)
    return counts


def _preferred_markers(language_style_stats: dict[str, Any] | None, *, limit: int = 8) -> list[str]:
    counts = _preferred_marker_counts(language_style_stats)
    return [
        marker
        for marker, _ in sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:limit]
    ]


def _source_turn_count(language_style_stats: dict[str, Any] | None) -> float | None:
    stats = language_style_stats or {}
    for key in ("client_turn_count", "turn_count", "total_turns", "n_turns"):
        value = _number(stats.get(key))
        if value and value > 0:
            return value
    turn_length = _turn_length_stats(language_style_stats)
    for key in ("count", "n", "turn_count"):
        value = _number(turn_length.get(key))
        if value and value > 0:
            return value
    return None


def _style_hedging_level(
    language_style_stats: dict[str, Any] | None,
    fallback: Literal["low", "medium", "high"],
) -> Literal["low", "medium", "high"]:
    stats = language_style_stats or {}
    for key in ("hedging_level", "hedge_level"):
        value = str(stats.get(key) or "").strip().lower()
        if value in {"low", "medium", "high"}:
            return value  # type: ignore[return-value]

    marker_counts = _preferred_marker_counts(language_style_stats)
    hedge_hits = sum(count for marker, count in marker_counts.items() if marker in _HEDGE_MARKERS)
    turns = _source_turn_count(language_style_stats)
    if turns and hedge_hits > 0:
        per_turn = hedge_hits / turns
        if per_turn >= 0.35:
            return "high"
        if per_turn >= 0.10:
            return "medium"
        return "low"
    if any(marker in _HEDGE_MARKERS for marker in marker_counts):
        return "medium"
    return fallback


def _style_emotional_explicitness(
    language_style_stats: dict[str, Any] | None,
) -> Literal["low", "medium", "high"] | None:
    stats = language_style_stats or {}
    for key in ("emotional_explicitness", "emotional_directness", "emotion_expression_level"):
        value = str(stats.get(key) or "").strip().lower()
        if value in {"low", "medium", "high"}:
            return value  # type: ignore[return-value]
    return None


def _length_targets(
    language_style_stats: dict[str, Any] | None,
    response_act_plan: dict[str, Any] | None,
) -> dict[str, int | None]:
    turn_length = _turn_length_stats(language_style_stats)
    mean = _number(turn_length.get("mean_characters"))
    median = _number(turn_length.get("median_characters"))
    p25 = _number(turn_length.get("p25_characters") or turn_length.get("q1_characters"))
    p75 = _number(turn_length.get("p75_characters") or turn_length.get("q3_characters"))
    p90 = _number(turn_length.get("p90_characters"))

    if mean is None and median is None:
        return {
            "target": None,
            "min": None,
            "max": None,
            "hard_max": None,
            "sentences": None,
        }

    center = median if median is not None else mean
    assert center is not None
    mean = mean if mean is not None else center
    minimum = p25 if p25 is not None else max(4.0, center * 0.62)
    maximum = p75 if p75 is not None else max(center, mean * 1.45)
    if p90 is not None:
        maximum = min(maximum, p90)
    hard_max = p90 if p90 is not None else max(maximum, maximum * 1.25)

    main_act = (response_act_plan or {}).get("main_act")
    if main_act == "logistics_response":
        center *= 0.55
        minimum *= 0.45
        maximum *= 0.65
        hard_max *= 0.75
    elif main_act == "answer_fact":
        center *= 0.78
        minimum *= 0.65
        maximum *= 0.85
        hard_max *= 0.90
    elif main_act == "express_feeling_with_example":
        center *= 1.10
        maximum *= 1.15
        hard_max *= 1.10

    minimum_i = max(3, round(minimum))
    target_i = max(minimum_i, round(center))
    maximum_i = max(target_i, round(maximum))
    hard_max_i = max(maximum_i, round(hard_max))

    sentence_stats = _sentence_stats(language_style_stats)
    sentence_center = _number(sentence_stats.get("median") or sentence_stats.get("median_sentences"))
    if sentence_center is None:
        sentence_center = _number(sentence_stats.get("mean") or sentence_stats.get("mean_sentences"))
    if sentence_center is not None:
        target_sentences = max(1, min(4, round(sentence_center)))
    elif main_act == "logistics_response":
        target_sentences = 1
    elif main_act == "express_feeling_with_example":
        target_sentences = 2
    else:
        target_sentences = 1 if target_i <= 30 else 2 if target_i <= 55 else 3

    return {
        "target": target_i,
        "min": minimum_i,
        "max": maximum_i,
        "hard_max": hard_max_i,
        "sentences": target_sentences,
    }


def _certainty_for_context(
    base_plan: LinguisticRealizationPlan,
    response_act_plan: dict[str, Any] | None,
    attribution_frame: AttributionFrame,
) -> Literal["low", "medium", "high"]:
    main_act = (response_act_plan or {}).get("main_act")
    if main_act in {"answer_fact", "logistics_response"}:
        return "high"
    if main_act in {"soft_resistance_or_clarification", "defensive_clarification"}:
        return "low"
    if attribution_frame.attribution_target in {"unclear", "core_belief"}:
        # Even deep self-interpretation should normally remain tentative unless
        # it is a directly established fact.
        return "low"
    return base_plan.certainty_level


def build_session_aware_linguistic_plan(
    *,
    latent_state_after: LatentPsychologicalState,
    subjective_appraisal: SubjectiveAppraisal,
    attribution_frame: AttributionFrame,
    disclosure_plan: DisclosurePlan,
    response_act_plan: dict[str, Any] | None,
    language: str = "zh",
    recent_client_utterances: Sequence[str] | None = None,
    language_style_stats: dict[str, Any] | None = None,
) -> LinguisticRealizationPlan:
    base_plan = build_linguistic_realization_plan(
        latent_state_after=latent_state_after,
        subjective_appraisal=subjective_appraisal,
        attribution_frame=attribution_frame,
        disclosure_plan=disclosure_plan,
    )

    certainty = _certainty_for_context(base_plan, response_act_plan, attribution_frame)
    fallback_hedging: Literal["low", "medium", "high"] = (
        "high" if certainty == "low" else "low" if certainty == "high" else "medium"
    )
    hedging = _style_hedging_level(language_style_stats, fallback_hedging)
    preferred_markers = _preferred_markers(language_style_stats)
    length = _length_targets(language_style_stats, response_act_plan)

    emotional_explicitness = base_plan.emotional_explicitness
    style_emotion = _style_emotional_explicitness(language_style_stats)
    max_introspection = (response_act_plan or {}).get("max_introspection")
    allow_emotion = (response_act_plan or {}).get("allow_emotional_expression", True)
    if not allow_emotion or max_introspection in {"none", "low"}:
        emotional_explicitness = "low"
    elif style_emotion is not None:
        emotional_explicitness = style_emotion

    constraints = [
        *base_plan.utterance_constraints,
        *_language_constraints(language),
        *_response_act_constraints(response_act_plan),
        *_dedupe_constraints(recent_client_utterances or []),
    ]
    if preferred_markers:
        constraints.append(
            "Source-grounded habitual markers may recur naturally (do not force one every turn): "
            + " / ".join(preferred_markers)
            + "."
        )
    if length["min"] and length["max"]:
        constraints.append(
            f"Match the source turn shape: usually about {length['min']}-{length['max']} characters "
            f"and around {length['sentences']} sentence(s); avoid expanding a short thought into a polished psychological summary."
        )
        if length["hard_max"]:
            constraints.append(
                f"Unless required factual content makes it impossible, keep the reply under about {length['hard_max']} characters."
            )

    surface_updates: dict[str, Any] = {
        "certainty_level": certainty,
        "emotional_explicitness": emotional_explicitness,
        "hedging_level": hedging,
        "target_length_chars": length["target"],
        "target_length_min_chars": length["min"],
        "target_length_max_chars": length["max"],
        "hard_max_length_chars": length["hard_max"],
        "target_sentence_count": length["sentences"],
        "preferred_markers": preferred_markers,
        "habitual_style_repetition_allowed": True,
        "avoid_semantic_repetition": True,
        "metaphor_or_body_expression": None,
        "utterance_constraints": constraints,
    }

    main_act = (response_act_plan or {}).get("main_act")
    if max_introspection == "none" or main_act in {"answer_fact", "logistics_response"}:
        surface_updates.update(
            {
                "speech_style": "direct",
                "emotional_explicitness": "low",
            }
        )
    return base_plan.model_copy(update=surface_updates)


def build_generic_linguistic_plan(
    *,
    latent_state_after: LatentPsychologicalState,
    subjective_appraisal: SubjectiveAppraisal,
    attribution_frame: AttributionFrame,
    disclosure_plan: DisclosurePlan,
    response_act_plan: dict[str, Any] | None,
    language: str = "zh",
) -> LinguisticRealizationPlan:
    """Generic realization for expression ablations; never uses person-specific stats."""
    return build_session_aware_linguistic_plan(
        latent_state_after=latent_state_after,
        subjective_appraisal=subjective_appraisal,
        attribution_frame=attribution_frame,
        disclosure_plan=disclosure_plan,
        response_act_plan=response_act_plan,
        language=language,
        recent_client_utterances=[],
        language_style_stats=None,
    )
