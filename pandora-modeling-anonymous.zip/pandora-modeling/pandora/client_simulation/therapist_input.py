from __future__ import annotations


from enum import Enum


class TherapistUtteranceType(str, Enum):
    FACTUAL_QUESTION = "factual_question"
    EMOTION_QUESTION = "emotion_question"
    REFLECTION = "reflection"
    NORMALIZATION = "normalization"
    CHALLENGE = "challenge"
    INVALIDATION = "invalidation"
    SELF_DISCLOSURE = "self_disclosure"
    LOGISTICS = "logistics"
    MINIMAL_RESPONSE = "minimal_response"
    OTHER = "other"


def classify_therapist_utterance(text: str) -> TherapistUtteranceType:
    t = text.strip()

    if any(x in t for x in ["想太多", "太敏感", "这没什么", "你应该", "必须", "别矫情"]):
        return TherapistUtteranceType.INVALIDATION

    if any(x in t for x in ["下次", "时间", "星期", "预约", "咨询室", "到这里"]):
        return TherapistUtteranceType.LOGISTICS

    if t in {"嗯", "嗯嗯", "对", "是的", "好的"} or len(t) <= 3:
        return TherapistUtteranceType.MINIMAL_RESPONSE

    if any(x in t for x in ["什么时候", "多长", "多久", "看什么", "有没有", "会不会", "是什么"]):
        return TherapistUtteranceType.FACTUAL_QUESTION

    if any(x in t for x in ["听起来", "我听到", "你好像", "你似乎"]):
        return TherapistUtteranceType.REFLECTION

    if any(x in t for x in ["感觉", "心情", "感受", "难受", "害怕", "焦虑"]):
        return TherapistUtteranceType.EMOTION_QUESTION

    if any(x in t for x in ["正常", "可以理解", "挺好的", "有意义"]):
        return TherapistUtteranceType.NORMALIZATION

    if any(x in t for x in ["不是特别严重", "很清晰", "舒适区", "阻碍"]):
        return TherapistUtteranceType.CHALLENGE

    return TherapistUtteranceType.OTHER


def _state_update_utterance_type(therapist_utterance: str) -> tuple[str, str]:
    classified = classify_therapist_utterance(therapist_utterance).value
    mapped = {
        "logistics": "logistics",
        "factual_question": "factual_question",
        "emotion_question": "reflective_statement",
        "reflection": "reflective_statement",
        "normalization": "reflective_statement",
        "challenge": "challenge_or_confrontation",
        "invalidation": "invalidation",
    }.get(classified, "factual_question")
    return classified, mapped
