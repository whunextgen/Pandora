from __future__ import annotations


from typing import Any


def _normalize_utterance_type(value: str | None) -> str:
    return (value or "factual_question").strip().lower()


def _factual_slot(text: str, utterance_type: str) -> str | None:
    if utterance_type == "logistics":
        if any(token in text for token in ["\u4e0b\u6b21", "\u661f\u671f", "\u9884\u7ea6", "\u65f6\u95f4"]):
            return "appointment_time"
        if "\u54a8\u8be2\u5ba4" in text:
            return "room_arrangement"
        return "logistics"

    if utterance_type == "factual_question":
        if any(
            token in text
            for token in ["\u4ec0\u4e48\u65f6\u5019", "\u591a\u4e45", "\u591a\u957f", "\u65f6\u95f4"]
        ):
            return "time_or_duration"
        if "\u770b\u4ec0\u4e48" in text:
            return "content_or_activity"
        if any(token in text for token in ["\u6709\u6ca1\u6709", "\u4f1a\u4e0d\u4f1a"]):
            return "yes_no"
        if "\u662f\u4ec0\u4e48" in text:
            return "definition_or_fact"
        return "factual_detail"

    return None


def build_response_act_plan(
    *,
    therapist_utterance: str,
    therapist_utterance_type: str | None,
) -> dict[str, Any]:
    utterance_type = _normalize_utterance_type(therapist_utterance_type)
    factual_slot = _factual_slot(therapist_utterance, utterance_type)
    plan: dict[str, Any] = {
        "main_act": "respond_in_context",
        "must_answer_question": False,
        "factual_slot": factual_slot,
        "max_introspection": "medium",
        "allow_emotional_expression": True,
        "answer_first": False,
    }

    if utterance_type == "factual_question":
        plan.update(
            {
                "main_act": "answer_fact",
                "must_answer_question": True,
                "max_introspection": "low",
                "allow_emotional_expression": True,
                "answer_first": True,
            }
        )
    elif utterance_type == "logistics":
        plan.update(
            {
                "main_act": "logistics_response",
                "must_answer_question": True,
                "max_introspection": "none",
                "allow_emotional_expression": False,
                "answer_first": True,
            }
        )
    elif utterance_type == "challenge_or_confrontation":
        plan.update(
            {
                "main_act": "soft_resistance_or_clarification",
                "must_answer_question": False,
                "max_introspection": "medium",
                "allow_emotional_expression": True,
            }
        )
    elif utterance_type == "invalidation":
        plan.update(
            {
                "main_act": "defensive_clarification",
                "must_answer_question": False,
                "max_introspection": "low",
                "allow_emotional_expression": True,
            }
        )
    elif utterance_type == "reflective_statement":
        plan.update(
            {
                "main_act": "confirm_or_refine_reflection",
                "must_answer_question": False,
                "max_introspection": "medium",
                "allow_emotional_expression": True,
            }
        )

    return plan
