from __future__ import annotations


from collections.abc import Sequence


from pandora.schemas import (
    AblationMode, DialogueTurnRecord, LatentPsychologicalState,
    MemoryActivationResult, MemoryActivationScore, MemoryDisclosureState,
    MemoryItem, SupervisionSignal,
)


def full_memory_oracle_policy(
    *,
    client_memory_bank: Sequence[MemoryItem],
) -> tuple[MemoryActivationResult, list[MemoryItem], list[MemoryDisclosureState]]:
    activated_ids = [str(memory.memory_id) for memory in client_memory_bank]
    memory_scores = [
        MemoryActivationScore(
            memory_id=str(memory.memory_id),
            surface_cue_match=1.0,
            emotion_match=1.0,
            need_match=1.0,
            core_belief_match=1.0,
            mechanism_match=1.0,
            supervision_safety_adjustment=0.0,
            total_activation_score=1.0,
            disclosure_allowed=True,
            blocked_reason=None,
        )
        for memory in client_memory_bank
    ]
    disclosure_states = [
        MemoryDisclosureState(
            memory_id=str(memory.memory_id),
            activated=True,
            emotional_activation_strength=1.0,
            cognitive_accessibility=1.0,
            narratability="clearly_narrated",
            disclosure_allowed=True,
            disclosure_mode=("core_belief_statement" if int(memory.disclosure_level) == 3 else "explicit_event"),
            reason="Full-memory oracle: all memories are directly accessible and narratable.",
        )
        for memory in client_memory_bank
    ]
    activation = MemoryActivationResult(
        activated_memory_ids=activated_ids,
        disclosure_permission_level=3,
        activation_reason="Full-memory oracle: all memory items are activated without gradual blocking.",
        blocked_memory_ids=[],
        blocked_reason="No memories blocked in full-memory oracle baseline.",
        memory_scores=memory_scores,
    )
    return activation, list(client_memory_bank), disclosure_states


def activate_memories(
    *,
    latest_therapist_utterance: str,
    recent_dialogue_history: Sequence[DialogueTurnRecord],
    current_latent_state: LatentPsychologicalState,
    client_memory_bank: Sequence[MemoryItem],
    supervision_signal: SupervisionSignal,
    ablation_mode: AblationMode,
) -> tuple[MemoryActivationResult, list[MemoryItem], list[MemoryDisclosureState]]:
    # Old callers keep their signature; access no longer depends on psychological thresholds.
    del latest_therapist_utterance, recent_dialogue_history, current_latent_state, supervision_signal, ablation_mode
    return full_memory_oracle_policy(client_memory_bank=client_memory_bank)
