from __future__ import annotations


from collections.abc import Sequence


from typing import Literal


from pandora.schemas import (
    AttributionFrame,
    AttributionTarget,
    ClientExpressionPlan,
    ClientStance,
    CognitiveDistortion,
    DialogueTurnRecord,
    DisclosurePlan,
    LatentPsychologicalState,
    LinguisticRealizationPlan,
    MemoryDisclosureState,
    MemoryItem,
    SpeechStyle,
    SubjectiveAppraisal,
    SupervisionSignal,
)


def _clamp(value: float) -> float:
    return max(0.0, min(1.0, value))


def _first(items: Sequence[str], default: str) -> str:
    for item in items:
        if item.strip():
            return item
    return default


def _active_core_belief(state: LatentPsychologicalState) -> str | None:
    if state.active_core_belief:
        return state.active_core_belief
    return next(iter(state.core_beliefs), None)


def _emotion_reflection_missed(supervision_signal: SupervisionSignal) -> bool:
    evaluation = supervision_signal.therapist_technique_evaluation
    return (
        supervision_signal.technique_opportunities.listening_opportunities.emotion_reflection.yes
        and (not evaluation.emotion_reflection.used or evaluation.emotion_reflection.score == -1)
    )


def _matched_insight_support(state: LatentPsychologicalState, supervision_signal: SupervisionSignal) -> bool:
    evaluation = supervision_signal.therapist_technique_evaluation
    opportunities = supervision_signal.technique_opportunities
    relational_ready = state.perceived_safety >= 0.50 and state.trust >= 0.45
    explanation_matched = opportunities.influence_opportunities.explanation.yes and evaluation.explanation.score == 1
    confrontation_matched = (
        opportunities.influence_opportunities.confrontation.yes
        and evaluation.confrontation.score == 1
        and relational_ready
    )
    return explanation_matched and relational_ready or confrontation_matched


def _expected_stance(state: LatentPsychologicalState, supervision_signal: SupervisionSignal) -> ClientStance:
    if state.emotional_arousal >= 0.78 and state.perceived_safety <= 0.42:
        return "emotionally_overwhelmed"
    if state.defensiveness >= 0.7 or state.avoidance_tendency >= 0.72:
        return "defensive"
    if state.avoidance_tendency >= 0.6:
        return "avoidant"
    if state.self_awareness_level <= 0.32:
        return "confused"
    if _matched_insight_support(state, supervision_signal) and state.self_awareness_level >= 0.6:
        return "intellectualized"
    if state.trust >= 0.62 and state.perceived_safety >= 0.6 and state.disclosure_readiness >= 0.55:
        return "open"
    return "hesitant"


def build_subjective_appraisal(
    *,
    latent_state_after: LatentPsychologicalState,
    latest_therapist_utterance: str,
    activated_memories: Sequence[MemoryItem],
    recent_dialogue: Sequence[DialogueTurnRecord],
    supervision_signal: SupervisionSignal,
) -> SubjectiveAppraisal:
    recent_client_text = recent_dialogue[-1].client_response.utterance if recent_dialogue else ""
    lead_memory = activated_memories[0].content if activated_memories else ""
    perceived_event = _first(
        [lead_memory, latest_therapist_utterance, recent_client_text, *latent_state_after.presenting_concerns],
        "this conversation is brushing against something tender",
    )
    active_belief = _active_core_belief(latent_state_after)
    if active_belief and latent_state_after.core_belief_activation >= 0.55:
        perceived_threat = f"It could mean I am {active_belief}."
    elif latent_state_after.defensiveness >= 0.6:
        perceived_threat = "I might be pushed into something I am not ready to explain."
    else:
        perceived_threat = "I could be judged or misunderstood if I say too much."

    if latent_state_after.self_awareness_level < 0.4:
        perceived_self_implication = _first(
            [latent_state_after.current_self_explanation],
            "Maybe I am just handling this badly.",
        )
    elif active_belief:
        perceived_self_implication = f"Part of me worries this says something bad about me, like being {active_belief}."
    else:
        perceived_self_implication = "This seems tied to a deeper pattern in how I react."

    perceived_interpersonal_implication = _first(
        latent_state_after.interpersonal_patterns,
        "If I open up, someone might judge me.",
    )
    confidence = _clamp(
        0.28
        + 0.34 * latent_state_after.problem_clarity
        + 0.24 * latent_state_after.self_awareness_level
        + 0.12 * latent_state_after.mentalization_level
        - 0.12 * latent_state_after.emotional_arousal
        + (0.04 if _matched_insight_support(latent_state_after, supervision_signal) else 0.0)
    )

    secondary_emotion = latent_state_after.dominant_emotions[1] if len(latent_state_after.dominant_emotions) > 1 else None
    return SubjectiveAppraisal(
        perceived_event=perceived_event,
        perceived_threat=perceived_threat,
        dominant_emotion=latent_state_after.dominant_emotion,
        secondary_emotion=secondary_emotion,
        perceived_self_implication=perceived_self_implication,
        perceived_interpersonal_implication=perceived_interpersonal_implication,
        appraisal_confidence=confidence,
    )


def generate_attribution_frame(
    *,
    latent_state_after: LatentPsychologicalState,
    activated_memories: Sequence[MemoryItem],
    latest_therapist_utterance: str,
    supervision_signal: SupervisionSignal,
    recent_dialogue: Sequence[DialogueTurnRecord],
) -> AttributionFrame:
    del latest_therapist_utterance, recent_dialogue
    active_belief = _active_core_belief(latent_state_after)
    surface_concern = _first(latent_state_after.presenting_concerns, "the situation")
    emotion_reflection_missed = _emotion_reflection_missed(supervision_signal)
    analysis_helpful = _matched_insight_support(latent_state_after, supervision_signal)
    target: AttributionTarget

    if latent_state_after.self_awareness_level < 0.4:
        distortion: CognitiveDistortion
        if latent_state_after.defensiveness >= 0.65:
            target = "environment"
            statement = f"Maybe it is mostly the situation around {surface_concern} getting to me."
            distortion = "catastrophizing" if latent_state_after.emotional_arousal > 0.7 else "none"
        else:
            target = "self_behavior"
            statement = latent_state_after.current_self_explanation
            distortion = "emotional_reasoning" if latent_state_after.core_belief_activation >= 0.55 else "all_or_nothing"
        return AttributionFrame(
            attribution_target=target,
            attribution_statement=statement,
            is_misattribution=bool(active_belief and latent_state_after.core_belief_activation >= 0.5),
            cognitive_distortion=distortion,
            hidden_underlying_belief=active_belief,
            awareness_gap="The client feels distress strongly but still explains it through a surface or defensive frame.",
        )

    if latent_state_after.self_awareness_level < 0.7 or emotion_reflection_missed:
        target = "unclear" if emotion_reflection_missed else "relationship"
        belief_tail = f" underneath, maybe something about being {active_belief}" if active_belief else ""
        statement = (
            f"It sounds bigger than just {surface_concern}, but I am not fully sure what it means{belief_tail}."
        )
        return AttributionFrame(
            attribution_target=target,
            attribution_statement=statement,
            is_misattribution=target != "core_belief",
            cognitive_distortion="mind_reading" if latent_state_after.defensiveness >= 0.55 else "none",
            hidden_underlying_belief=active_belief,
            awareness_gap="The client notices contradiction and depth but cannot yet name the deeper belief cleanly.",
        )

    target = "core_belief" if active_belief else "relationship"
    memory_hint = activated_memories[0].content if activated_memories else surface_concern
    statement = (
        f"Maybe this is not only about {surface_concern}. When {memory_hint}, it starts to feel like I am {active_belief}."
        if active_belief
        else f"I think this pattern in {surface_concern} says something about how I expect people to react to me."
    )
    return AttributionFrame(
        attribution_target=target,
        attribution_statement=statement,
        is_misattribution=False,
        cognitive_distortion="none" if analysis_helpful else None,
        hidden_underlying_belief=active_belief,
        awareness_gap="The client can connect surface distress to a deeper pattern with relatively little gap.",
    )


def build_disclosure_plan(
    *,
    latent_state_after: LatentPsychologicalState,
    memory_disclosure_states: Sequence[MemoryDisclosureState],
    activated_memories: Sequence[MemoryItem],
    attribution_frame: AttributionFrame,
    supervision_signal: SupervisionSignal,
) -> DisclosurePlan:
    del memory_disclosure_states, attribution_frame
    return DisclosurePlan(
        disclosure_depth=3,
        disclose_memory_ids=[str(memory.memory_id) for memory in activated_memories],
        hint_memory_ids=[],
        avoid_memory_ids=[],
        allowed_content=(
            "All activated memories are available. Use content relevant to the therapist's current question."
        ),
        forbidden_content="Do not expose internal memory IDs, metadata, or latent-state scores.",
        expected_client_stance=_expected_stance(latent_state_after, supervision_signal),
    )


def build_linguistic_realization_plan(
    *,
    latent_state_after: LatentPsychologicalState,
    subjective_appraisal: SubjectiveAppraisal,
    attribution_frame: AttributionFrame,
    disclosure_plan: DisclosurePlan,
) -> LinguisticRealizationPlan:
    """Build a generic surface-realization prior.

    Important: this layer does not decide *what* to disclose. It only provides a
    light linguistic prior that downstream person-specific realization may
    refine. Deep disclosure is therefore not allowed to mechanically imply
    high certainty or high emotional explicitness.
    """
    del subjective_appraisal

    stance = disclosure_plan.expected_client_stance
    speech_style: SpeechStyle
    if stance == "defensive":
        speech_style = "brief_withdrawn"
    elif stance == "avoidant":
        speech_style = "vague"
    elif stance == "confused":
        speech_style = "contradictory"
    elif stance == "intellectualized":
        speech_style = "intellectualized"
    elif stance == "emotionally_overwhelmed":
        speech_style = "emotionally_flooded"
    elif stance == "open":
        speech_style = "direct"
    else:
        speech_style = "hesitant"

    pronoun_focus: Literal["I", "others", "situation", "mixed"]
    if attribution_frame.attribution_target == "environment":
        pronoun_focus = "situation"
    elif attribution_frame.attribution_target in {"other_person", "relationship"}:
        pronoun_focus = "others"
    elif attribution_frame.attribution_target == "unclear":
        pronoun_focus = "mixed"
    else:
        pronoun_focus = "I"

    # Psychological interpretations should remain tentative by default.
    # High certainty is reserved downstream for concrete factual responses; it
    # is never granted merely because disclosure is deep or safety is high.
    certainty_level: Literal["low", "medium", "high"]
    if attribution_frame.attribution_target == "unclear" or stance in {"confused", "hesitant"}:
        certainty_level = "low"
    else:
        certainty_level = "medium"

    # Emotional explicitness follows the immediate stance/arousal state rather
    # than disclosure depth. A concise deep disclosure is fully valid.
    emotional_explicitness: Literal["low", "medium", "high"]
    if stance == "emotionally_overwhelmed":
        emotional_explicitness = "high"
    elif stance in {"defensive", "avoidant", "intellectualized"}:
        emotional_explicitness = "low"
    else:
        emotional_explicitness = "medium" if latent_state_after.dominant_emotion else "low"

    return LinguisticRealizationPlan(
        speech_style=speech_style,
        pronoun_focus=pronoun_focus,
        certainty_level=certainty_level,
        emotional_explicitness=emotional_explicitness,
        # Body language may come from source-grounded memory content, never a
        # generic template inserted by the expression planner.
        metaphor_or_body_expression=None,
        utterance_constraints=[
            "Do not mention latent variables, scores, or schema labels.",
            "Do not reveal inactive memories.",
            "If awareness is low, stay with surface explanation or uncertainty rather than polished self-analysis.",
            "Deep content may still be expressed briefly and tentatively; depth does not require high certainty or a long explanation.",
        ],
    )


def build_expression_plan(
    *,
    latent_state_after: LatentPsychologicalState,
    latest_therapist_utterance: str,
    recent_dialogue: Sequence[DialogueTurnRecord],
    supervision_signal: SupervisionSignal,
    activated_memories: Sequence[MemoryItem],
    memory_disclosure_states: Sequence[MemoryDisclosureState],
) -> ClientExpressionPlan:
    subjective_appraisal = build_subjective_appraisal(
        latent_state_after=latent_state_after,
        latest_therapist_utterance=latest_therapist_utterance,
        activated_memories=activated_memories,
        recent_dialogue=recent_dialogue,
        supervision_signal=supervision_signal,
    )
    attribution_frame = generate_attribution_frame(
        latent_state_after=latent_state_after,
        activated_memories=activated_memories,
        latest_therapist_utterance=latest_therapist_utterance,
        supervision_signal=supervision_signal,
        recent_dialogue=recent_dialogue,
    )
    disclosure_plan = build_disclosure_plan(
        latent_state_after=latent_state_after,
        memory_disclosure_states=memory_disclosure_states,
        activated_memories=activated_memories,
        attribution_frame=attribution_frame,
        supervision_signal=supervision_signal,
    )
    linguistic_plan = build_linguistic_realization_plan(
        latent_state_after=latent_state_after,
        subjective_appraisal=subjective_appraisal,
        attribution_frame=attribution_frame,
        disclosure_plan=disclosure_plan,
    )
    return ClientExpressionPlan(
        subjective_appraisal=subjective_appraisal,
        attribution_frame=attribution_frame,
        disclosure_plan=disclosure_plan,
        linguistic_realization_plan=linguistic_plan,
    )
