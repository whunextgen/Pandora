from __future__ import annotations


import json


import re


import textwrap


from collections.abc import Sequence


from typing import Any, TypeVar


from pydantic import BaseModel


from pandora.schemas import (
    ClientResponse,
    DialogueTurnRecord,
    RealTherapistTechniqueEvaluation,
    SupervisionSignal,
    TechniqueLabel,
    TechniqueOpportunitySignal,
    TechniqueUseScore,
)


StructuredModelT = TypeVar("StructuredModelT", bound=BaseModel)


TECHNIQUE_LABELS = (
    "clarification",
    "paraphrase",
    "emotion_reflection",
    "summary",
    "questioning",
    "explanation",
    "information",
    "immediacy",
    "self_disclosure",
    "confrontation",
)


VALIDATION_CUES = (
    "that sounds",
    "it sounds like",
    "it makes sense",
    "of course",
    "that must",
    "i can see",
    "i hear",
    "painful",
    "hard",
    "sad",
    "hurt",
    "听起来",
    "我能理解",
    "确实很难",
    "很不容易",
    "难受",
    "委屈",
)


SUMMARY_CUES = (
    "what i'm hearing",
    "what i hear",
    "it sounds like",
    "you're saying",
    "so when",
    "if i'm understanding",
    "也就是说",
    "你的意思是",
    "我听到的是",
    "总结一下",
)


QUESTION_OPENERS = ("what", "how", "when", "where", "could", "can", "would", "did")


ANALYSIS_CUES = ("pattern", "cycle", "part of", "goal", "steps", "organize", "structure")


DISTRESS_WORDS = (
    "sad",
    "cry",
    "hurt",
    "ashamed",
    "anxious",
    "scared",
    "empty",
    "overwhelmed",
    "upset",
    "tense",
    "难受",
    "焦虑",
    "害怕",
    "委屈",
    "痛苦",
    "绝望",
)


def _normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def _tokenize(text: str) -> set[str]:
    return set(re.findall(r"\w+", text.lower()))


def _extract_json_block(content: str) -> str:
    stripped = content.strip()
    if stripped.startswith("```"):
        stripped = re.sub(r"^```(?:json)?\s*", "", stripped)
        stripped = re.sub(r"\s*```$", "", stripped)
    return stripped.strip()


def _message_content_to_text(content: Any) -> str:
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        text_chunks = [item.text for item in content if hasattr(item, "text")]
        return "\n".join(text_chunks)
    return str(content)


def _normalize_speaker(value: str) -> str:
    normalized = _normalize(value)
    if normalized in {"t", "therapist", "counselor", "counsellor", "咨", "咨询师"}:
        return "therapist"
    if normalized in {"c", "client", "patient", "visitor", "来", "来访者"}:
        return "client"
    return normalized


def _latest_client_turn(dialogue_history: Sequence[DialogueTurnRecord]) -> DialogueTurnRecord | None:
    if not dialogue_history:
        return None
    return dialogue_history[-1]


def _client_response_context(
    dialogue_history: Sequence[DialogueTurnRecord],
    latest_client_response: ClientResponse | None,
) -> ClientResponse | None:
    if latest_client_response is not None:
        return latest_client_response
    latest_turn = _latest_client_turn(dialogue_history)
    if latest_turn is None:
        return None
    return latest_turn.client_response


def _uses_emotion_reflection(
    therapist_text: str,
    client_turn: DialogueTurnRecord | None,
    client_response: ClientResponse | None,
) -> bool:
    del client_turn
    lower = _normalize(therapist_text)
    if any(cue in lower for cue in VALIDATION_CUES):
        return True
    if client_response is None:
        return False
    affect_terms = {item.lower() for item in client_response.affect}
    return any(term in lower for term in affect_terms)


def _uses_summary(
    therapist_text: str,
    client_turn: DialogueTurnRecord | None,
    client_response: ClientResponse | None,
) -> bool:
    del client_turn
    lower = _normalize(therapist_text)
    if any(cue in lower for cue in SUMMARY_CUES):
        return True
    if client_response is None:
        return False
    overlap = _tokenize(lower) & _tokenize(client_response.utterance)
    return len(overlap) >= 4 and "?" not in therapist_text


def _uses_questioning(therapist_text: str) -> bool:
    lower = _normalize(therapist_text)
    return "?" in therapist_text or "？" in therapist_text or lower.startswith(QUESTION_OPENERS)


def _uses_explanation(therapist_text: str) -> bool:
    lower = _normalize(therapist_text)
    return any(cue in lower for cue in (*ANALYSIS_CUES, "模式", "循环", "原因", "意味着", "可能是因为"))


def _decision(yes: bool, reason: str):
    from pandora.schemas import TechniqueOpportunityDecision

    return TechniqueOpportunityDecision(yes=yes, reason=reason)


def _opportunity_decision(signal: TechniqueOpportunitySignal, technique: str):
    if technique in {"clarification", "paraphrase", "emotion_reflection", "summary"}:
        return getattr(signal.listening_opportunities, technique)
    return getattr(signal.influence_opportunities, technique)


def _heuristic_technique_opportunities(
    *,
    dialogue_history: Sequence[DialogueTurnRecord],
    latest_client_response: ClientResponse | None = None,
) -> TechniqueOpportunitySignal:
    latest_turn = _latest_client_turn(dialogue_history)
    client_response = _client_response_context(dialogue_history, latest_client_response)
    client_text = _normalize(client_response.utterance if client_response else "")
    client_affect = {item.lower() for item in client_response.affect} if client_response else set()
    client_state = latest_turn.latent_state_after if latest_turn is not None else None
    token_count = len(client_text.split())

    emotional_distress = (
        (client_state is not None and client_state.distress >= 0.6)
        or any(word in client_text for word in DISTRESS_WORDS)
        or bool(client_affect & set(DISTRESS_WORDS))
    )
    vague = token_count <= 10 or "not sure" in client_text or "i don't know" in client_text
    has_pattern = (
        any(phrase in client_text for phrase in ("always", "every time", "keep", "again", "pattern"))
        or (client_state is not None and len(client_state.interpersonal_patterns) >= 2)
    )
    broad_material = token_count >= 22 or (client_state is not None and len(client_state.presenting_concerns) >= 2)
    relationship_material = any(term in client_text for term in ("you", "therapist", "judge", "judged", "trust"))
    contradiction = any(term in client_text for term in ("but", "however", "although", "on the other hand"))

    from pandora.schemas import InfluenceTechniqueOpportunities, ListeningTechniqueOpportunities

    return TechniqueOpportunitySignal(
        listening_technique_needed=_decision(
            emotional_distress or vague or broad_material,
            "The client material indicates a need for receiving, clarifying, reflecting, or organizing.",
        ),
        influence_technique_needed=_decision(
            vague or has_pattern or relationship_material or contradiction,
            "The client material may benefit from further exploration, interpretation, immediacy, or gentle challenge.",
        ),
        listening_opportunities=ListeningTechniqueOpportunities(
            clarification=_decision(vague, "Client wording is vague or under-specified."),
            paraphrase=_decision(token_count >= 8, "The client has expressed enough material to restate the core meaning."),
            emotion_reflection=_decision(emotional_distress, "The client has explicit or implied emotional distress."),
            summary=_decision(broad_material, "The client has shared multiple details or themes that can be organized."),
        ),
        influence_opportunities=InfluenceTechniqueOpportunities(
            questioning=_decision(vague, "Further exploration can help the client elaborate concrete details or meanings."),
            explanation=_decision(has_pattern, "The client appears to describe a recurring pattern or mechanism."),
            information=_decision(False, "No clear need for psychoeducation or factual information is inferred."),
            immediacy=_decision(relationship_material, "The here-and-now relationship or fear of judgment may be relevant."),
            self_disclosure=_decision(False, "No strong indication that therapist self-disclosure is needed."),
            confrontation=_decision(contradiction, "There may be a meaningful contradiction or gap to point out gently."),
        ),
    )


def _heuristic_real_therapist_technique_evaluation(
    *,
    technique_opportunities: TechniqueOpportunitySignal,
    dialogue_history: Sequence[DialogueTurnRecord],
    latest_therapist_utterance: str,
    latest_client_response: ClientResponse | None = None,
) -> RealTherapistTechniqueEvaluation:
    latest_turn = _latest_client_turn(dialogue_history)
    client_response = _client_response_context(dialogue_history, latest_client_response)
    therapist_text = latest_therapist_utterance.strip()
    lower = _normalize(therapist_text)

    used_by_technique: dict[str, bool] = {
        "clarification": _uses_questioning(therapist_text) and _opportunity_decision(technique_opportunities, "clarification").yes,
        "paraphrase": _uses_summary(therapist_text, latest_turn, client_response),
        "emotion_reflection": _uses_emotion_reflection(therapist_text, latest_turn, client_response),
        "summary": any(cue in lower for cue in SUMMARY_CUES),
        "questioning": _uses_questioning(therapist_text),
        "explanation": _uses_explanation(therapist_text),
        "information": any(cue in lower for cue in ("you can", "you could", "try", "option", "resource", "建议")),
        "immediacy": any(cue in lower for cue in ("between us", "right now", "here", "with me", "此刻")),
        "self_disclosure": any(cue in lower for cue in ("i also", "for me", "my experience", "我也")),
        "confrontation": any(cue in lower for cue in ("but", "however", "at the same time", "可是")),
    }

    scores: dict[str, TechniqueUseScore] = {}
    primary: list[TechniqueLabel] = []
    for technique in TECHNIQUE_LABELS:
        used = used_by_technique[technique]
        opportunity = _opportunity_decision(technique_opportunities, technique)
        if used:
            score = 1 if opportunity.yes else 0
            primary.append(technique)  # type: ignore[arg-type]
            reason = "The therapist visibly used this technique in the current utterance."
            evidence = therapist_text
        elif opportunity.yes:
            score = -1
            reason = "This technique was clinically available but not visible in the therapist utterance."
            evidence = "No visible therapist wording for this technique."
        else:
            score = 0
            reason = "This technique was not used and was not clearly needed in this turn."
            evidence = "No visible therapist wording for this technique."
        scores[technique] = TechniqueUseScore(used=used, score=score, reason=reason, evidence=evidence)

    return RealTherapistTechniqueEvaluation(
        clarification=scores["clarification"],
        paraphrase=scores["paraphrase"],
        emotion_reflection=scores["emotion_reflection"],
        summary=scores["summary"],
        questioning=scores["questioning"],
        explanation=scores["explanation"],
        information=scores["information"],
        immediacy=scores["immediacy"],
        self_disclosure=scores["self_disclosure"],
        confrontation=scores["confrontation"],
        primary_techniques=primary,
        overall_reason="Heuristic online supervision aligned to the Exp1/Exp2 ten-technique schema.",
    )


def build_supervision_signal_from_exp1_exp2(
    *,
    technique_opportunities: TechniqueOpportunitySignal | dict[str, Any],
    therapist_technique_evaluation: RealTherapistTechniqueEvaluation | dict[str, Any],
) -> SupervisionSignal:
    if not isinstance(technique_opportunities, TechniqueOpportunitySignal):
        technique_opportunities = TechniqueOpportunitySignal.model_validate(technique_opportunities)
    if not isinstance(therapist_technique_evaluation, RealTherapistTechniqueEvaluation):
        therapist_technique_evaluation = RealTherapistTechniqueEvaluation.model_validate(therapist_technique_evaluation)
    return SupervisionSignal(
        technique_opportunities=technique_opportunities,
        therapist_technique_evaluation=therapist_technique_evaluation,
    )


def build_supervision_signal(
    *,
    dialogue_history: Sequence[DialogueTurnRecord],
    latest_therapist_utterance: str,
    latest_client_response: ClientResponse | None = None,
) -> SupervisionSignal:
    opportunities = _heuristic_technique_opportunities(
        dialogue_history=dialogue_history,
        latest_client_response=latest_client_response,
    )
    evaluation = _heuristic_real_therapist_technique_evaluation(
        technique_opportunities=opportunities,
        dialogue_history=dialogue_history,
        latest_therapist_utterance=latest_therapist_utterance,
        latest_client_response=latest_client_response,
    )
    return build_supervision_signal_from_exp1_exp2(
        technique_opportunities=opportunities,
        therapist_technique_evaluation=evaluation,
    )
