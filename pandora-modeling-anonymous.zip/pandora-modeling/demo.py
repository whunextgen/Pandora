"""Synthetic local check of the released modeling functions."""
from pandora.schemas import ClientResponse, LatentPsychologicalState, MemoryItem, MemoryKind
from pandora.client.memory_activation import full_memory_oracle_policy
from pandora.client.state_update import update_client_state
from pandora.client.expression_planning import build_expression_plan
from pandora.client_simulation.state_layer import postprocess_latent_state, NUMERIC_STATE_FIELDS, SOFT_BOUNDS
from pandora.client_simulation.therapist_input import _state_update_utterance_type
from pandora.client_simulation.response_act_layer import build_response_act_plan
from pandora.client_simulation.expression_planning_module import ExpressionPlanningRequest, process_expression_planning
from pandora.supervisor.supervisor import build_supervision_signal


def main():
    state = LatentPsychologicalState(**{name: .5 for name in NUMERIC_STATE_FIELDS})
    client = ClientResponse(
        utterance="I feel sad when I think about a recent setback.",
        expressed_emotion="sad", apparent_attribution="unclear", disclosure_depth=1,
        self_disclosure=.3, affect=["sad"],
    )
    memory = MemoryItem(memory_id="synthetic-event", kind=MemoryKind.SURFACE,
                        content="An invented recent setback.", disclosure_level=1, activation_threshold=1)
    activation, memories, descriptors = full_memory_oracle_policy(client_memory_bank=[memory])
    assert activation.activated_memory_ids == ["synthetic-event"] and not activation.blocked_memory_ids
    assert all(d.cognitive_accessibility == 1 and d.disclosure_allowed for d in descriptors)
    results = {}
    for label, utterance in {"matched": "听起来这让你很难受。", "missed": "这件事是什么时候发生的？"}.items():
        signal = build_supervision_signal(dialogue_history=[], latest_therapist_utterance=utterance,
                                         latest_client_response=client)
        raw = update_client_state(previous_state=state, latest_therapist_utterance=utterance,
                                  recent_dialogue_history=[], supervision_signal=signal,
                                  activated_memories=memories, memory_activation=activation,
                                  memory_disclosure_states=descriptors)
        classified, update_type = _state_update_utterance_type(utterance)
        diagnostics = {}
        bounded = postprocess_latent_state(previous_state=state, raw_state=raw,
                                          therapist_utterance_type=update_type, metadata=diagnostics)
        for name, record in diagnostics["state_postprocess"]["field_updates"].items():
            assert abs(record["bounded_delta"]) <= record["max_delta"] + 1e-12
            low, high = SOFT_BOUNDS.get(name, (0, 1))
            assert low <= getattr(bounded, name) <= high
        plan = build_expression_plan(latent_state_after=bounded, latest_therapist_utterance=utterance,
                                     recent_dialogue=[], supervision_signal=signal,
                                     activated_memories=memories, memory_disclosure_states=descriptors)
        response_act = build_response_act_plan(therapist_utterance=utterance, therapist_utterance_type=classified)
        process_expression_planning(ExpressionPlanningRequest(
            latent_state_after=bounded, subjective_appraisal=plan.subjective_appraisal,
            attribution_frame=plan.attribution_frame, disclosure_plan=plan.disclosure_plan,
            response_act_plan=response_act, recent_dialogue_history=[],
        ))
        results[label] = bounded
        print(label, "trust:", round(bounded.trust, 5), "safety:", round(bounded.perceived_safety, 5))
    assert results["matched"].trust > results["missed"].trust
    assert results["matched"].perceived_safety > results["missed"].perceived_safety
    print("All synthetic modeling checks passed. No API calls were made.")


if __name__ == "__main__":
    main()
